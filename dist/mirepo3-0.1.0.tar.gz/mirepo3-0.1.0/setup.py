from setuptools import setup, find_packages

setup(
    name="MIREPO3",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="RONALDO ROSADO",                         # Tu nombre
    author_email="ronald.rosa96@gmail.com",                 # Tu correo electrónico
    url="https://github.com/Economiststata/MIREPO3",     # URL del proyecto
)